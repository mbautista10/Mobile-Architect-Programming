package com.zybooks.mauriciobautista_option3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class NewRegisters extends AppCompatActivity {

    EditText username1, password2, reEnterPassword;
    Button RegButton;
    DataBaseHelper myDataBase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_registers);

        username1 = (EditText) findViewById(R.id.username1);
        password2 = (EditText) findViewById(R.id.password2);
        reEnterPassword = (EditText) findViewById(R.id.reEnterPassword);

        RegButton = (Button) findViewById(R.id.RegButton);

        myDataBase = new DataBaseHelper(this);

        RegButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username1.getText().toString();
                String pass = password2.getText().toString();
                String ReEnterPass = reEnterPassword.getText().toString();

                // Check to see if any text is empty
                if (user.equals("") || pass.equals("") || ReEnterPass.equals("")) {
                    Toast.makeText(NewRegisters.this, "Fill In All The Fields", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (pass.equals(ReEnterPass)){
                        Boolean userCheckResult = myDataBase.checkUserName(user);
                        if(userCheckResult == false){
                           Boolean regResult = myDataBase.insertData(user, pass);
                           if(regResult == true) {
                               Toast.makeText(NewRegisters.this, "Registration Successful", Toast.LENGTH_SHORT).show();

                               // Changes back to log in screen
                               Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                               startActivity(intent);
                           }
                           else{
                               Toast.makeText(NewRegisters.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                           }
                        }
                        else{
                            Toast.makeText(NewRegisters.this, "User Already Exists \n Please Sign In", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        Toast.makeText(NewRegisters.this, "Password Not Matching", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}