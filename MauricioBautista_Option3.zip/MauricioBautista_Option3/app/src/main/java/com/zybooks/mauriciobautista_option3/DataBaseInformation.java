package com.zybooks.mauriciobautista_option3;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DataBaseInformation extends AppCompatActivity {

    EditText name, gender, dateOfBirth, startWeight, targetWeight;
    Button create, update, delete, view;
    DataBaseHelperTwo UserDataBase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_base_information);

        name = (EditText) findViewById(R.id.PersonName);
        gender = (EditText) findViewById(R.id.GenderType);
        dateOfBirth = (EditText) findViewById(R.id.DateOfBirth);
        startWeight = (EditText) findViewById(R.id.StartWeight);
        targetWeight =  (EditText) findViewById(R.id.TargetWeight);

        create = (Button) findViewById(R.id.buttonCreate);
        update = (Button) findViewById(R.id.buttonUpdate);
        delete = (Button) findViewById(R.id.buttonDelete);
        view = (Button) findViewById(R.id.buttonView);

        UserDataBase =  new DataBaseHelperTwo(this);


        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = name.getText().toString();
                String genderTXT = gender.getText().toString();
                String dateOfBirthTXT = dateOfBirth.getText().toString();
                String startWeightTXT = startWeight.getText().toString();
                String targetWeightTXT = targetWeight.getText().toString();

                Boolean checkInsertData;
                checkInsertData = UserDataBase.insertUserData(nameTXT, genderTXT, dateOfBirthTXT, startWeightTXT, targetWeightTXT);
                if(checkInsertData == true)
                    Toast.makeText(DataBaseInformation.this, "New Entry Inserted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(DataBaseInformation.this, "New Entry Not Inserted", Toast.LENGTH_SHORT).show();
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = name.getText().toString();
                String genderTXT = gender.getText().toString();
                String dateOfBirthTXT = dateOfBirth.getText().toString();
                String startWeightTXT = startWeight.getText().toString();
                String targetWeightTXT = targetWeight.getText().toString();

                Boolean checkUpdateData = UserDataBase.UpdateUserData(nameTXT,genderTXT, dateOfBirthTXT, startWeightTXT, targetWeightTXT);
                if(checkUpdateData == true)
                    Toast.makeText(DataBaseInformation.this, "Entry Updated", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(DataBaseInformation.this, "New Entry Not Updated", Toast.LENGTH_SHORT).show();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            // Deletes Data by Name
            @Override
            public void onClick(View view) {
                String nameTXT = name.getText().toString();

                Boolean checkDeleteData = UserDataBase.DeleteUserData(nameTXT);
                if(checkDeleteData == true)
                    Toast.makeText(DataBaseInformation.this, "Entry Deleted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(DataBaseInformation.this, "Entry Not Deleted", Toast.LENGTH_SHORT).show();
            }
        });

        view.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Cursor result = UserDataBase.GetData();
                if(result.getCount() == 0) {
                    Toast.makeText(DataBaseInformation.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while(result.moveToNext()) {
                    buffer.append("Name: " + result.getString(0) + "\n");
                    buffer.append("Gender Type: " + result.getString(1) + "\n");
                    buffer.append("Date of Birth: " + result.getString(2) + "\n");
                    buffer.append("Start Weight: " + result.getString(3) + "\n");
                    buffer.append("Target Weight: " + result.getString(4) + "\n\n");
                }

                // Grid Builder
                AlertDialog.Builder builder = new AlertDialog.Builder(DataBaseInformation.this);
                builder.setCancelable(true);
                builder.setTitle("User Entries");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });
    }
}