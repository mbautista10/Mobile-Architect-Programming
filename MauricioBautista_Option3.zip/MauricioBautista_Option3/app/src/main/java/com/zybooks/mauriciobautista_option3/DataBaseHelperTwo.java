package com.zybooks.mauriciobautista_option3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DataBaseHelperTwo extends SQLiteOpenHelper {
    public DataBaseHelperTwo(Context context) {

        super(context, "Userdata.db", null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase UserDataBase) {
        UserDataBase.execSQL("create Table UserDetails (name Text primary key, gender Text, dateOfBirth Text, startWeight Text, targetWeight Text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase UserDataBase, int i, int i1) {
        UserDataBase.execSQL("drop Table if exists UserDetails");
    }

    // Inserts User Information
    public boolean insertUserData(String name, String gender, String dateOfBirth, String startWeight, String targetWeight) {
        SQLiteDatabase UserDataBase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Name", name);
        contentValues.put("Gender Type", gender);
        contentValues.put("Date Of Birth", dateOfBirth);
        contentValues.put("Start Weight", startWeight);
        contentValues.put("Target Weight", targetWeight);
        long result = UserDataBase.insert("UserDetails", null, contentValues);
        if (result == -1)
            return false;
        else
            {
            return true;
        }
    }

    // Updates User Data
    public boolean UpdateUserData(String name, String gender, String dateOfBirth, String startWeight, String targetWeight) {
        SQLiteDatabase UserDataBase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        //contentValues.put("Name", name);
        contentValues.put("Gender Type", gender);
        contentValues.put("Date Of Birth", dateOfBirth);
        contentValues.put("Start Weight", startWeight);
        contentValues.put("Target Weight", targetWeight);
        // Creates Cursor
        Cursor cursor = UserDataBase.rawQuery("Select * from UserDetail where name = ?", new String[] {name});
        if (cursor.getCount() > 0) {

            long result = UserDataBase.update("UserDetails", contentValues, "name = ?", new String[]{name});
            if (result == -1) {
                return false;
            }
            else {
                return true;
            }
        }
        else {
            return false;
        }
    }

    // Deletes User Data
    public boolean DeleteUserData(String name) {
        SQLiteDatabase UserDataBase = this.getWritableDatabase();

        // Creates Cursor
        Cursor cursor = UserDataBase.rawQuery("Select * from UserDetail where name = ?", new String[] {name});
        if (cursor.getCount() > 0) {

            long result = UserDataBase.delete("UserDetails", "name = ?", new String[]{name});
            if (result == -1) {
                return false;
            }
            else {
                return true;
            }
        }
        else {
            return false;
        }
    }

    // Returns Data
    public Cursor GetData() {
        SQLiteDatabase UserDataBase = this.getWritableDatabase();

        // Creates Cursor
        Cursor cursor = UserDataBase.rawQuery("Select * from UserDetails", null);
        return cursor;
    }
}
