package com.zybooks.mauriciobautista_option3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBaseHelper extends SQLiteOpenHelper {
    public DataBaseHelper(Context context){
        super (context, "login.db", null, 1);
    }

    @Override
    // Creates data table
    public void onCreate(SQLiteDatabase myDataBase) {
        myDataBase.execSQL("create Table users(username Text primary key, password Text)");
    }

    // Drops table if exists
    @Override
    public void onUpgrade(SQLiteDatabase myDataBase, int i, int i1) {
        myDataBase.execSQL("drop Table if exists users");
    }

    // Checks if user exist
    public boolean insertData(String username, String password) {
        SQLiteDatabase myDataBase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = myDataBase.insert("users", null, contentValues);

        if (result == -1) {
            return false;
        }
        else {
            return true;
        }
    }

    public boolean checkUserName(String username) {
        SQLiteDatabase myDataBase = this.getWritableDatabase();
        Cursor cursor = myDataBase.rawQuery("select * from users where username = ?", new String[] {username});
        if (cursor.getCount() > 0) {
            return true;
        }
        else {
            return false;
        }
    }
    // Checks for username and password
    public boolean checkUserNamePassword(String username, String password) {
        SQLiteDatabase myDataBase = this.getWritableDatabase();
        Cursor cursor = myDataBase.rawQuery("select * from users where username = ? and password = ?", new String[] {username, password});
        if (cursor.getCount() > 0) {
            return true;
        }
        else {
            return false;
        }
    }



}
